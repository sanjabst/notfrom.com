
$(function() {

  var menu_ul = $('.aside-menu > li > ul'),
      menu_a  = $('.aside-menu > li > a');
  menu_ul.hide();
  menu_a.click(function(e) {
      e.preventDefault();
      if(!$(this).hasClass('active')) {
          menu_a.removeClass('active');
          menu_ul.filter(':visible').slideUp('normal');
          $(this).addClass('active').next().stop(true,true).slideDown('normal');
      } else {
          $(this).removeClass('active');
          $(this).next().stop(true,true).slideUp('normal');
      }
  });

  $('.aside-submenu a').on('click', function(){

      $(this).toggleClass('active');
  });

  // Hide landing-page, show main content
  $(window).on('load', function(){
    $('.landing-pg-wrapper').delay(3000).fadeOut(function(){
        $('.main_wrapper, footer').removeClass('hidden');
    })
  });

  // Login modal
  var modal = document.getElementById('id01');
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  // Shipping Modal
  var modal = document.getElementById('id02');
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  // myValues
  var modal = document.getElementById('my_values');
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  // Favorities active function
  $('.fa-heart').on('click', function(){
    $(this).toggleClass('active');
  })

  $(".flip-arrow").on('click', function(){
      $(this).find(".fa-angle-down").toggleClass("caretup");
    });
});
